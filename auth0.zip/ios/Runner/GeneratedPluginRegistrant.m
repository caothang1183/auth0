//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_auth0/FlutterAuth0Plugin.h>)
#import <flutter_auth0/FlutterAuth0Plugin.h>
#else
@import flutter_auth0;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterAuth0Plugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterAuth0Plugin"]];
}

@end
